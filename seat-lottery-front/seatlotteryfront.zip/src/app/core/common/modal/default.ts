export function jsonEqual(a, b): boolean {   
  return JSON.stringify(a) === JSON.stringify(b);   
}   
export class _CONSTANTS {
  currency : string = 'GBP'
}

