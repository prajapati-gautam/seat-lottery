export declare function svgMap(svgwrapper);
