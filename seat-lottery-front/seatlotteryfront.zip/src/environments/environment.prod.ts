export const environment = {
  production: true,
  APIURL  : 'https://www.yocat.net/backend/API/V1/',
  APIURLBACKEND  : 'https://www.yocat.net/backend/',
  BASEURL : 'https://www.yocat.net/',
  _FORMAT:'?_format=json',
  _HAL_FORMAT:'?_format=hal_json',
  SANDBOX_TOKEN : 'Token test-valid-key',
  SANDBOX_API   : 'https://secure-sandbox.zaffo.com/api/1.0/client/',
};


//test-valid-key
