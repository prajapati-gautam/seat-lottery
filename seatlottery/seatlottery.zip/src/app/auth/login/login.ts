export class User {

  constructor(
    public user: string,
    public pass: string,
  ) {  }

}
