export declare function svgMap(svg,premap);
