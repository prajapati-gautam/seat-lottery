export const environment = {
  production: true,
  api_url   : 'https://yocat.net'
};
